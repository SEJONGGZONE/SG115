<?
    error_reporting( E_ALL );
    ini_set( "display_errors", 1 );

    echo "MySql 연결 테스트<br>";

    $servername = "localhost";
    $username = "root";
    $password = "Gzone1234%";

    // Create connection
    // $db = new mysqli($servername, $username, $password);

    $db=mysqli_connect("127.0.0.1", "root", "hwang88", "test");

    
    
    if ($db) {
        echo "connect : 성공<br>";
    } else{
        echo "disconnect : 실패<br>";
    }
    $result = mysqli_query($db, 'SELECT VERSION() as VERSION');
    $data = mysqli_fetch_assoc($result);
    echo $data['VERSION'];
?>