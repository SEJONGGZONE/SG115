import { fabric } from 'fabric';

fabric.Object.prototype.objectCaching = false;
