import 'jest-canvas-mock';
